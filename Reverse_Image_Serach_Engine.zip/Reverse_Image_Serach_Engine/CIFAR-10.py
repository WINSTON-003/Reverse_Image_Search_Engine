# import pickle
import os

import numpy as np
#
#
# # Function to unpickle the data
# def unpickle(file):
#     with open(file, 'rb') as fo:
#         dict = pickle.load(fo, encoding='bytes')
#     return dict
#
#
# # Specify the path to the folder containing the CIFAR-10 data files
# folder_path = r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cifar-10-batches-py\\'
#
#
# # Unpickle each batch file and combine them into a single dataset
# def load_cifar10_data(folder_path):
#     train_data = []
#     train_labels = []
#
#     for i in range(1, 6):  # There are 5 training batches
#         batch = unpickle(folder_path + f'data_batch_{i}')
#         train_data.append(batch[b'data'])
#         train_labels += batch[b'labels']
#
#     train_data = np.concatenate(train_data)
#     train_data = train_data.reshape((50000, 3, 32, 32)).transpose(0, 2, 3, 1)  # reshape to 50,000 x 32 x 32 x 3
#
#     # Load the test batch
#     test_batch = unpickle(folder_path + 'test_batch')
#     test_data = test_batch[b'data']
#     test_labels = test_batch[b'labels']
#
#     test_data = test_data.reshape((10000, 3, 32, 32)).transpose(0, 2, 3, 1)
#
#     return (train_data, train_labels), (test_data, test_labels)
#
#
# # Load the data
# (train_data, train_labels), (test_data, test_labels) = load_cifar10_data(folder_path)
#
#
#
# import os
#
# # Specify the folder where you want to save the extracted files
# save_folder = r'C:\Users\WINSTON A\Documents\Monisha Mam Project\CIFAR-10 datasets\\'
#
# # Ensure the folder exists
# if not os.path.exists(save_folder):
#     os.makedirs(save_folder)
#
# # Save the training data
# np.save(save_folder + 'train_data.npy', train_data)
# np.save(save_folder + 'train_labels.npy', train_labels)
#
# # Save the test data
# np.save(save_folder + 'test_data.npy', test_data)
# np.save(save_folder + 'test_labels.npy', test_labels)

from sklearn.model_selection import train_test_split


os.chdir(r"C:\Users\WINSTON A\Documents\Monisha Mam Project\CIFAR-10 datasets")

train_features = np.load('CIFAR-10_datasetstrain_data.npy')
test_features = np.load('CIFAR-10_datasetstest_data.npy')

train_labels = np.load('CIFAR-10_datasetstrain_labels.npy')
test_labels = np.load('CIFAR-10_datasetstest_labels.npy')

# X_train, X_val, y_train, y_val = train_test_split(train_features, train_labels, test_size=0.2, random_state=42)

#
# from tensorflow.keras.models import Model
# from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, Flatten, Dense
#
# input_layer = Input(shape=(32, 32, 3))
# x = Conv2D(32, (3, 3), activation='relu')(input_layer)
# x = MaxPooling2D((2, 2))(x)
# x = Flatten()(x)
# x = Dense(64, activation='relu')(x)
# output_layer = Dense(10, activation='softmax')(x)
#
# model = Model(inputs=input_layer, outputs=output_layer)
#
# # Compile the model
# model.compile(optimizer='adam',
#               loss='sparse_categorical_crossentropy',
#               metrics=['accuracy'])
#
# history = model.fit(X_train, y_train,
#                     epochs=10,  # Number of epochs
#                     batch_size=32,
#                     validation_data=(X_val, y_val))
#
# test_loss, test_accuracy = model.evaluate(test_features, test_labels)
# print(f'Test Loss: {test_loss}')
# print(f'Test Accuracy: {test_accuracy}')
#
# # Save the model
# model.save('cifar10_model.h5')
#
# from tensorflow.keras.models import load_model
# import cv2
#
# # Load the trained model
# trained_model = load_model('cifar10_model.h5')

import cv2 as cv
import tensorflow as tf
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model
from tensorflow.keras.models import load_model
#
# # Load the pre-trained ResNet50 model, without the top (fully connected) layers
# base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(32, 32, 3))
#
# # Add new layers for CIFAR-10 classification
# x = base_model.output
# x = GlobalAveragePooling2D()(x)
# x = Dense(512, activation='relu')(x)
# predictions = Dense(10, activation='softmax')(x)
#
# # Create the model
# model = Model(inputs=base_model.input, outputs=predictions)
#
# # Compile the model
# model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
#
# # Display the model architecture
# model.summary()

# Load CIFAR-10 data
# (x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()

# # Normalize the data
# x_train = x_train.astype('float32') / 255.0
# x_test = x_test.astype('float32') / 255.0

# # Train the model
# model.fit(train_features, train_labels, validation_data=(test_features, test_labels), epochs=5, batch_size=64)
#
# model.save('CIFAR-10_Resnet50_Model.h5')

trained_model = load_model("CIFAR-10_Resnet50_Model.h5")


img_path = r"C:\Users\WINSTON A\Downloads\download (4).jpeg"
img = cv.imread(img_path)
img = cv.resize(img, (32, 32))  # Resize image to match model input
img = img.astype('float32') / 255.0  # Normalize pixel values
img = np.expand_dims(img, axis=0)  # Add batch dimension

# Predict the class for your image
predictions = trained_model.predict(img)
predicted_class_index = np.argmax(predictions, axis=1)

# Map index to class label if you have a label map
class_labels = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']
predicted_label = class_labels[predicted_class_index[0]]

print(f'Predicted Class Index: {predicted_class_index[0]}')
print(f'Predicted Label: {predicted_label}')






