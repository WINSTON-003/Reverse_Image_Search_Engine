import pytesseract as tess
from PIL import Image

tess.pytesseract.tesseract_cmd = r'C:\Users\WINSTON A\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'

image_path = r'C:\Users\WINSTON A\Documents\Monisha Mam Project\Book Data\book-covers\Food-Drink\0000221.jpg'

image = Image.open(image_path)

extracted_string = tess.image_to_string(image)

cleaned_text = extracted_string.strip()
print("Extracted Text:  ")
print(cleaned_text)