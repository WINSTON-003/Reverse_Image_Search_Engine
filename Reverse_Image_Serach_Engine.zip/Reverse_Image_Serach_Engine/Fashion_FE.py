import os
import numpy as np
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.models import Model
from tensorflow.keras.layers import GlobalAveragePooling2D
import cv2

os.chdir(r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Fashion Data")

# Define the path to your dataset
image_dir = r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Fashion Data\images"

# Load the pre-trained ResNet50 model without the top classification layers
base_model = ResNet50(weights='imagenet', include_top=False)
x = base_model.output
x = GlobalAveragePooling2D()(x)
model = Model(inputs=base_model.input, outputs=x)
def preprocess_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array = preprocess_input(img_array)
    return img_array
def extract_features(img_path):
    img = preprocess_image(img_path)
    features = model.predict(img)
    return features.flatten()
# Extract features for all images
features_list = []
for img_name in os.listdir(image_dir):
    img_path = os.path.join(image_dir, img_name)
    if os.path.isfile(img_path):
        features = extract_features(img_path)
        features_list.append(features)
# Convert list to numpy array
features_array = np.array(features_list)
np.save('fashion_product_features.npy', features_array)


