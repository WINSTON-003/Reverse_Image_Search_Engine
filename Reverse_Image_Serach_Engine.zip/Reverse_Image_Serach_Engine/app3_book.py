import os
import numpy as np
from flask import Flask, request, render_template
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.preprocessing.image import img_to_array
from sklearn.metrics.pairwise import cosine_similarity
from tensorflow.keras.models import Model
import cv2
import io
from PIL import Image
import base64

app = Flask(__name__)

os.chdir(r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Book Data\book-covers")

# Paths to pre-trained feature vectors, labels, and images
features = np.load('book_cover_resnet_features.npy')
labels = np.load('book_cover_labels.npy')
image_dir = r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Book Data\book-covers"

# Load the ResNet50 model for feature extraction
base_model = ResNet50(weights='imagenet', include_top=False, pooling='avg')
model = Model(inputs=base_model.input, outputs=base_model.output)


def preprocess_image(image):
    image = cv2.resize(image, (224, 224))
    image = image / 255.0  # Normalize to [0, 1] range
    image = np.expand_dims(image, axis=0)  # Add batch dimension
    return image


def predict_and_find_similar_images(query_image, features, labels, image_dir, top_n=5):
    query_feature = model.predict(query_image)  # query_image has shape (1, 224, 224, 3)
    similarities = cosine_similarity(query_feature, features)

    # Get the index of the most similar class
    predicted_label_index = np.argmax(np.mean(similarities, axis=1))
    predicted_label = labels[predicted_label_index].astype(str)

    # Get the directory for the predicted class
    class_dir = os.path.join(image_dir, predicted_label)
    if not os.path.isdir(class_dir):
        print(f"Class directory '{class_dir}' does not exist.")
        return [], predicted_label

    # Get all images in the predicted class directory
    class_images = sorted(os.listdir(class_dir))
    top_similar_images = [os.path.join(class_dir, img) for img in class_images[:top_n]]

    return top_similar_images, predicted_label


@app.route('/', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':
        file = request.files['image']

        # Read the uploaded image
        image_stream = io.BytesIO(file.read())
        image = Image.open(image_stream)
        image = np.array(image)

        query_image = preprocess_image(image)
        similar_images, predicted_label = predict_and_find_similar_images(query_image, features, labels, image_dir)

        # Convert similar images to base64
        similar_images_base64 = []
        for img_path in similar_images:
            if os.path.isfile(img_path):
                with open(img_path, "rb") as img_file:
                    img_str = base64.b64encode(img_file.read()).decode('utf-8')
                    similar_images_base64.append(img_str)
            else:
                print(f"Image file {img_path} does not exist.")

        # Encode the query image itself to display on the webpage
        image_stream.seek(0)
        query_image_str = base64.b64encode(image_stream.read()).decode('utf-8')

        return render_template('index3.html', query_image=query_image_str, similar_images=similar_images_base64,
                               predicted_label=predicted_label)

    return render_template('index3.html')


if __name__ == '__main__':
    app.run(debug=True)
