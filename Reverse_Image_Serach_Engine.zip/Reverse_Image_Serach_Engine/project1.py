import scipy.io
import os
import cv2 as cv
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import VGG16
from tensorflow.keras.models import Model

os.chdir(r'C:\\Users\\WINSTON A\\Documents\\Monisha Mam Project')

# Load the .mat file
mat_file = scipy.io.loadmat('cars_annos.mat')

# Explore the contents
print(mat_file.keys())

# Assuming 'annotations' is a key in the .mat file
annotations = mat_file['annotations']

# Example: Extract class labels (this may vary depending on the dataset structure)
class_labels = annotations['class']

# Print the first few class labels to verify
print(class_labels[:10])

annotations = mat_file['annotations']
class_names = mat_file['class_names']

print(annotations)
print(class_names)

image_path = os.chdir(r'C:\\Users\\WINSTON A\\Documents\\Monisha Mam Project\\cars_train\\cars_train\\')

def image_preprocess(image_path):
    image = cv.imread(image_path)
    image = cv.resize(image, (224,224))
    image = image/255.0  #Normalizing
    image = image.astype(np.float32)
    return image

def preprocess_images_in_directory(input_dir):
    # List to store preprocessed images (if you want to keep them in memory)
    preprocessed_images = []

    # Iterate over all files in the input directory
    for filename in os.listdir(input_dir):
        # Construct the full file path
        file_path = os.path.join(input_dir, filename)

        # Ensure it's a file and not a subdirectory
        if os.path.isfile(file_path):
            try:
                # Preprocess the image
                preprocessed_image = image_preprocess(file_path)

                # Append to list (optional)
                preprocessed_images.append(preprocessed_image)

            except Exception as e:
                print(f"Error processing file {file_path}: {e}")

    return preprocessed_images


input_dir = r'C:\\Users\\WINSTON A\\Documents\\Monisha Mam Project\\cars_train\\cars_train\\'
preprocessed_images = preprocess_images_in_directory(input_dir)
images = np.array(preprocessed_images)
labels = np.array(class_labels)
print(preprocessed_images)
# Load pre-trained VGG16 model + higher level layers
base_model = VGG16(weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('fc1').output)
# Extract features
features = model.predict(images)
# Save features for later use
np.save('car_features.npy', features)
np.save('car_labels.npy', labels)






