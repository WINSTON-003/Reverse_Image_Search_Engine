import streamlit as st
from PIL import Image
import numpy as np
import os
import base64
import io
import requests
from tensorflow.keras.applications import VGG16, ResNet50
from tensorflow.keras.models import Model
from tensorflow.keras.applications.vgg16 import preprocess_input
from sklearn.metrics.pairwise import cosine_similarity
import cv2
import pytesseract as tess

# Setup Tesseract
tess.pytesseract.tesseract_cmd = r'C:\Users\WINSTON A\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'

# Load precomputed features and initialize models
car_features = np.load(r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cars_train\car_features.npy')
car_image_dir = r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cars_train\cars_train'
car_image_files = sorted([f for f in os.listdir(car_image_dir) if os.path.isfile(os.path.join(car_image_dir, f))])

car_base_model = VGG16(weights='imagenet')
car_model = Model(inputs=car_base_model.input, outputs=car_base_model.get_layer('fc1').output)

fashion_features = np.load(r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Fashion Data\fashion_product_features.npy")
fashion_image_dir = r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Fashion Data\images"
fashion_image_files = sorted([f for f in os.listdir(fashion_image_dir) if os.path.isfile(os.path.join(fashion_image_dir, f))])

fashion_base_model = ResNet50(weights='imagenet', include_top=False, pooling='avg')
fashion_model = Model(inputs=fashion_base_model.input, outputs=fashion_base_model.output)

# Replace 'your_api_key' with your actual Pexels API key
API_KEY = "jkSGlTPK5jBavtwoA0dkXZu60L3dMmjaiaMQQzTtnavWfZRUjZKC27Jj"


def preprocess_image(image):
    image = cv2.resize(image, (224, 224))
    image = image / 255.0
    return image


def find_car_similar_images(query_image, features, top_n=30):
    query_feature = car_model.predict(np.expand_dims(query_image, axis=0))
    similarities = cosine_similarity(query_feature, features)
    similar_indices = np.argsort(similarities[0])[::-1][:top_n]
    return similar_indices


def find_fashion_similar_images(query_image, features, top_n=30):
    query_feature = fashion_model.predict(np.expand_dims(query_image, axis=0))
    similarities = cosine_similarity(query_feature, features)
    similar_indices = np.argsort(similarities[0])[::-1][:top_n]
    return similar_indices


def search_pexels(query):
    url = "https://api.pexels.com/v1/search"
    query = query.strip().replace("\n", " ")
    from urllib.parse import quote_plus
    query = quote_plus(query)

    params = {
        "query": query,
        "per_page": 30,
        "page": 1
    }
    headers = {
        "Authorization": API_KEY
    }

    try:
        response = requests.get(url, headers=headers, params=params, timeout=10, verify=False)
        if response.status_code == 200:
            photos = response.json().get("photos", [])
            return photos
        else:
            return []
    except requests.exceptions.RequestException as e:
        return []


def image_to_base64(img):
    buffered = io.BytesIO()
    img.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode('utf-8')


def main():
    st.title('Image-Based Search Engine')

    menu = ["Select Domain", "Upload Image", "Results"]
    choice = st.sidebar.selectbox("Menu", menu)

    if choice == "Select Domain":
        st.subheader("Select Domain")
        domain = st.radio("Select Domain:", ("Automobile", "Fashion", "Text Extraction"))
        st.session_state['domain'] = domain

    elif choice == "Upload Image":
        st.subheader("Upload Image")
        uploaded_file = st.file_uploader("Choose an image...", type=['jpg', 'png', 'jpeg'])
        if uploaded_file:
            image = Image.open(uploaded_file)
            st.image(image, caption='Uploaded Image', use_column_width=True)
            st.session_state['uploaded_image'] = image

            if st.button('Process Image'):
                if 'domain' not in st.session_state:
                    st.error("Please select a domain first.")
                else:
                    domain = st.session_state['domain']
                    image_array = np.array(image)
                    query_image = preprocess_image(image_array)

                    if domain == 'Automobile':
                        similar_indices = find_car_similar_images(query_image, car_features)
                        similar_images = []
                        for idx in similar_indices:
                            similar_image_path = os.path.join(car_image_dir, car_image_files[idx])
                            similar_image = Image.open(similar_image_path)
                            similar_images.append(image_to_base64(similar_image))
                        st.session_state['similar_images'] = similar_images
                        st.session_state['query_image'] = image_to_base64(image)
                        st.success("Image processed successfully. Go to Results to view.")

                    elif domain == 'Fashion':
                        query_image = preprocess_input(cv2.resize(image_array, (224, 224)))
                        similar_indices = find_fashion_similar_images(query_image, fashion_features)
                        similar_images = []
                        for idx in similar_indices:
                            similar_image_path = os.path.join(fashion_image_dir, fashion_image_files[idx])
                            similar_image = Image.open(similar_image_path)
                            similar_images.append(image_to_base64(similar_image))
                        st.session_state['similar_images'] = similar_images
                        st.session_state['query_image'] = image_to_base64(image)
                        st.success("Image processed successfully. Go to Results to view.")

                    elif domain == 'Book':
                        extracted_text = tess.image_to_string(image)
                        cleaned_text = extracted_text.strip().replace("\n", " ")
                        images = search_pexels(cleaned_text)
                        st.session_state['pexels_images'] = [img['src']['large'] for img in images]
                        st.session_state['query_image'] = image_to_base64(image)
                        st.success("Text extracted and search performed. Go to Results to view.")

    elif choice == "Results":
        st.subheader("Results")
        if 'query_image' in st.session_state:
            st.image(f"data:image/jpeg;base64,{st.session_state['query_image']}", caption='Query Image',
                     use_column_width=True)

            if 'similar_images' in st.session_state:
                st.write("Similar Images:")
                for img_base64 in st.session_state['similar_images']:
                    st.image(f"data:image/jpeg;base64,{img_base64}", use_column_width=True)

            elif 'pexels_images' in st.session_state:
                st.write("Images from Pexels:")
                for img_url in st.session_state['pexels_images']:
                    st.image(img_url, use_column_width=True)
        else:
            st.warning("Please upload an image first.")


if __name__ == '__main__':
    main()
