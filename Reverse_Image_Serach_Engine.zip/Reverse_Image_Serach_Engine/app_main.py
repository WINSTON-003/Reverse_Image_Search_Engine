from tensorflow.keras.preprocessing import image
import numpy as np
from tensorflow.keras.applications.vgg16 import VGG16, decode_predictions, preprocess_input
from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import requests
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

# Ensure the upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Replace 'your_api_key' with your actual Pexels API key
API_KEY = "jkSGlTPK5jBavtwoA0dkXZu60L3dMmjaiaMQQzTtnavWfZRUjZKC27Jj"

# Load the pre-trained VGG16 model with weights trained on ImageNet
model = VGG16(weights='imagenet', include_top=True, pooling='avg')


def search_pexels(query):
    url = "https://api.pexels.com/v1/search"
    params = {
        "query": query,
        "per_page": 15,
        "page": 1
    }
    headers = {
        "Authorization": API_KEY


    }
    try:
        response = requests.get(url, headers=headers, params=params, timeout=10)
        if response.status_code == 200:
            photos = response.json().get("photos", [])
            return photos
        else:
            print(f"Failed to retrieve images. Status code: {response.status_code}")
            return []
    except requests.exceptions.RequestException as e:
        print(f"An error occurred while searching for images: {e}")
        return []


@app.route('/', methods=['GET', 'POST'])
def upload_and_search():
    if request.method == 'POST':
        # Get the uploaded image
        file = request.files['image']
        if file:
            # Save the uploaded image
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(file_path)

            # Load the image and preprocess it for VGG16
            img = image.load_img(file_path, target_size=(224, 224))
            array = image.img_to_array(img)
            array = np.expand_dims(array, axis=0)
            array = preprocess_input(array)

            # Predict with VGG16
            preds = model.predict(array)
            decoded_preds = decode_predictions(preds, top=2)  # Get top 2 predictions

            # Start with the top prediction
            top_prediction = decoded_preds[0][0][1]
            print(f"Top prediction: {top_prediction}")
            search_results = search_pexels(top_prediction)

            # If no images found, use the second prediction
            if not search_results:
                second_prediction = decoded_preds[0][1][1]
                print(f"No images found for '{top_prediction}'. Trying second prediction: '{second_prediction}'")
                search_results = search_pexels(second_prediction)
                top_prediction = second_prediction  # Update the top prediction to the second one

            # Render the results on the webpage
            if not search_results:
                return render_template('results.html', prediction=top_prediction, images=search_results)
            else:
                return render_template('results.html', prediction=top_prediction, images=search_results)

    return render_template('upload.html')


if __name__ == '__main__':
    app.run(debug=True)
