from flask import Flask, request, render_template
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from tensorflow.keras.applications import VGG16
from tensorflow.keras.models import Model
import cv2
import os
import shutil

app = Flask(__name__)


os.chdir(r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cars_train\\')

# Load the saved features and labels
features = np.load('car_features.npy')
# Directory where car images are stored
image_dir = r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cars_train\cars_train'

# Get list of all image file names in the directory
image_files = sorted([f for f in os.listdir(image_dir) if os.path.isfile(os.path.join(image_dir, f))])

# Load the pre-trained model for feature extraction
base_model = VGG16(weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('fc1').output)

def preprocess_image(image_path):
    image = cv2.imread(image_path)
    image = cv2.resize(image, (224, 224))
    image = image / 255.0
    return image


# Function to find similar images
def find_similar_images(query_image, features, top_n=20):
    query_feature = model.predict(np.expand_dims(query_image, axis=0))
    similarities = cosine_similarity(query_feature, features)
    similar_indices = np.argsort(similarities[0])[::-1][:top_n]
    return similar_indices

@app.route('/', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':
        # Save uploaded image
        file = request.files['image']
        filename = file.filename
        file_path = os.path.join(r'C:\Users\WINSTON A\Documents\Pycharm Projects\Academic project\static\\', filename)
        file.save(file_path)

        # Preprocess and find similar images
        # Preprocess and find similar images
        query_image = preprocess_image(file_path)
        similar_indices = find_similar_images(query_image, features)

        similar_images = []
        for idx in similar_indices:
            # Get the path of the similar image
            src_path = os.path.join(image_dir, image_files[idx])
            dst_path = os.path.join(r'C:\Users\WINSTON A\Documents\Pycharm Projects\Academic project\static\\', os.path.basename(src_path))  # Copy to static/
            shutil.copy(src_path, dst_path)  # Copy the image to static/
            similar_images.append(os.path.basename(src_path))  # Store the basename for web access

        # Render the template with the query image and similar images
        return render_template('index1.html', query_path=filename, similar_images=similar_images)

    return render_template('index1.html')

if __name__ == '__main__':
    app.run(debug=True)
