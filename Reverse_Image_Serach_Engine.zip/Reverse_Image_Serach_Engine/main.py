from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.vgg16 import VGG16, decode_predictions, preprocess_input
from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import requests
import os
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.models import Model
import cv2
import io
from io import BytesIO
from PIL import Image
import base64
import pytesseract as tess
tess.pytesseract.tesseract_cmd = r'C:\Users\WINSTON A\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'


app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

# Ensure the upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


car_features = np.load(r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cars_train\car_features.npy')
car_image_dir = r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cars_train\cars_train'
car_image_files = sorted([f for f in os.listdir(car_image_dir) if os.path.isfile(os.path.join(car_image_dir, f))])

car_base_model = VGG16(weights='imagenet')
car_model = Model(inputs=car_base_model.input, outputs=car_base_model.get_layer('fc1').output)

fashion_features = np.load(r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Fashion Data\fashion_product_features.npy")
fashion_image_dir = r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Fashion Data\images"
fashion_image_files = sorted([f for f in os.listdir(fashion_image_dir) if os.path.isfile(os.path.join(fashion_image_dir, f))])

fashion_base_model = ResNet50(weights='imagenet', include_top=False, pooling='avg')
fashion_model = Model(inputs=fashion_base_model.input, outputs=fashion_base_model.output)

# Replace 'your_api_key' with your actual Pexels API key
API_KEY = "jkSGlTPK5jBavtwoA0dkXZu60L3dMmjaiaMQQzTtnavWfZRUjZKC27Jj"

# Pretrained VGG16 model for general image classification
model = VGG16(weights='imagenet', include_top=True, pooling='avg')

def preprocess_image(image):
    image = cv2.resize(image, (224, 224))
    image = image / 255.0
    return image

def find_car_similar_images(query_image, features, top_n=50):
    """
    Find the top N similar car images based on cosine similarity.
    Args:
        query_image (np.array): Preprocessed query image.
        features (np.array): Precomputed feature vectors of car images.
        top_n (int): Number of similar images to return.
    Returns:
        list: Indices of the top N most similar car images.
    """
    # Predict feature vector for query image
    query_feature = car_model.predict(np.expand_dims(query_image, axis=0))
    similarities = cosine_similarity(query_feature, features)
    similar_indices = np.argsort(similarities[0])[::-1][:top_n]
    return similar_indices


def find_fashion_similar_images(query_image, features, top_n=50):
    query_feature = fashion_model.predict(np.expand_dims(query_image, axis=0))
    similarities = cosine_similarity(query_feature, features)
    similar_indices = np.argsort(similarities[0])[::-1][:top_n]
    return similar_indices


def search_pexels(query):
    url = "https://api.pexels.com/v1/search"
    API_KEY = "jkSGlTPK5jBavtwoA0dkXZu60L3dMmjaiaMQQzTtnavWfZRUjZKC27Jj"

    # Clean and encode the query to handle spaces and special characters
    query = query.strip().replace("\n", " ")
    from urllib.parse import quote_plus
    query = quote_plus(query)

    params = {
        "query": query,
        "per_page": 30,
        "page": 1
    }
    headers = {
        "Authorization": API_KEY
    }

    try:
        print(f"Query: {query}")  # For debugging
        response = requests.get(url, headers=headers, params=params, timeout=10, verify=False)
        if response.status_code == 200:
            photos = response.json().get("photos", [])
            return photos
        else:
            print(f"Failed to retrieve images. Status code: {response.status_code}")
            return []
    except requests.exceptions.RequestException as e:
        print(f"An error occurred while searching for images: {e}")
        return []


def image_to_base64(img_path):
    with open(img_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode('utf-8')

def url_to_base64(image_url):
    try:
        response = requests.get(image_url)
        img = Image.open(BytesIO(response.content))
        buffered = BytesIO()
        img.save(buffered, format="JPEG")
        return base64.b64encode(buffered.getvalue()).decode("utf-8")
    except Exception as e:
        print(f"An error occurred while converting image URL to base64: {e}")
        return None

@app.route('/', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':

        # Get the uploaded image
        file = request.files.get('image')


        # Save the uploaded image temporarily
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        # Reset file pointer to the beginning
        file.seek(0)

        # Read the image file into a PIL image object
        try:
            image_pil = Image.open(file)
            image_array = np.array(image_pil)
        except Exception as e:
            print(f"Error opening image: {e}")
            return "Error processing image"

        query_image = preprocess_image(image_array)

        # Identify the domain
        domain = request.form.get('domain')  # Assume user selects a domain (e.g., automobile, fashion)

        if domain == 'automobile':
            features = car_features
            similar_indices = find_car_similar_images(query_image, features)

            similar_images = []
            for idx in similar_indices:
                # Load similar image directly and convert to base64
                similar_image_path = os.path.join(car_image_dir, car_image_files[idx])
                similar_image = Image.open(similar_image_path)
                buffered = io.BytesIO()
                similar_image.save(buffered, format="JPEG")
                img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
                similar_images.append(img_str)

            # Convert query image to base64
            buffered = io.BytesIO()
            query_image_pil = Image.fromarray((query_image * 255).astype('uint8'))
            query_image_pil.save(buffered, format="JPEG")
            query_image_str = base64.b64encode(buffered.getvalue()).decode('utf-8')

            return render_template('index2.html', query_image=query_image_str, similar_images=similar_images)


        elif domain == 'fashion':

            try:

                image_pil = Image.open(file)

                image_array = np.array(image_pil)


            except Exception as e:

                print(f"Error opening image: {e}")

                return "Error processing image"

            # Resize the image to the required dimensions

            image_1 = cv2.resize(image_array, (224, 224))

            # Preprocess the image for model input

            query_image = preprocess_input(image_1)

            # Find similar images based on the preprocessed query image

            similar_indices = find_fashion_similar_images(query_image, fashion_features)

            similar_images = []

            for idx in similar_indices:
                # Load similar image directly and convert to base64

                similar_image_path = os.path.join(fashion_image_dir, fashion_image_files[idx])

                similar_image = Image.open(similar_image_path)

                buffered = io.BytesIO()

                similar_image.save(buffered, format="JPEG")

                img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')

                similar_images.append(img_str)

            # Reverse normalization for display (multiply by 255)

            display_image = (query_image * 255).astype('uint8')

            # Convert the original image to base64 for display

            buffered = io.BytesIO()

            query_image_pil = Image.open(file_path)  # Use the saved image file

            query_image_pil.save(buffered, format="JPEG")

            query_image_str = base64.b64encode(buffered.getvalue()).decode('utf-8')

            return render_template('index3.html', query_image=query_image_str, similar_images=similar_images)


        else:

            try:

                # Open the image using PIL

                image_pil = Image.open(file)

                # Extract text using Tesseract

                extracted_text = tess.image_to_string(image_pil)

                cleaned_text = extracted_text.strip().replace("\n", " ")
                print(cleaned_text)

                # Convert the query image to base64 for display

                query_image_base64 = image_to_base64(file_path)

                # Search for similar images using the extracted text

                images = search_pexels(cleaned_text)

                # Render the results on the webpage with the query image

                return render_template('index.html', query_image=query_image_base64, images=images)


            except Exception as e:

                print(f"Error processing image: {e}")

                return "Error processing image"


    return render_template('home_m_1.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Simulate login validation
        # If login is successful
        return redirect(url_for('upload_page'))
    return render_template('login_m.html')

@app.route('/upload')
def upload_page():
    return render_template('upload_m.html')



if __name__ == '__main__':
    app.run(debug=True)
