// Array of hero video URLs
const heroVideos = ["video1.mp4", "video2.mp4", "video3.mp4"];

// Function to update the hero video dynamically
function updateHeroVideo() {
  const heroVideo = document.querySelector("video");
  const randomIndex = Math.floor(Math.random() * heroVideos.length);
  heroVideo.src = heroVideos[randomIndex];
  heroVideo.load(); // Load the new video
  heroVideo.play(); // Play the new video
}

// About Us slideshow functionality
const aboutContent = document.getElementById("about-content");
const aboutTexts = [
  "Welcome to [Your Website Name], your ultimate destination for discovering stunning images from around the world. Our mission is to provide users with a powerful and intuitive search engine that makes finding the perfect image effortless. We believe that visuals have the power to inspire, inform, and connect people.",
  "With a vast collection of high-quality images, we cater to photographers, designers, marketers, and anyone in need of captivating visuals. Our user-friendly interface and advanced search features ensure that you can quickly find exactly what you're looking for.",
  "We value our customers and strive for excellence in everything we do. Join us on this visual journey and unlock a world of creativity at your fingertips.",
  "Join us on our journey to make a difference in the world.",
];

let aboutIndex = 0;

// Function to update the About Us content
function updateAboutContent() {
  aboutContent.textContent = aboutTexts[aboutIndex];
  aboutIndex = (aboutIndex + 1) % aboutTexts.length; // Loop back to the start
}
function scrollToSection(sectionId) {
  const section = document.getElementById(sectionId);

  // Scroll to the section smoothly
  section.scrollIntoView({ behavior: "smooth" });

  // Highlight the section with a temporary background color change
  section.style.transition = "background-color 0.5s ease";
  section.style.backgroundColor = "#ffeb3b"; // Yellow highlight

  // Remove the highlight after a short time
  setTimeout(() => {
    section.style.backgroundColor = ""; // Reset to default background
  }, 2000); // 2 seconds delay before removing the highlight
}

// Handle image upload (you'll need to implement the actual upload logic)
const uploadInput = document.getElementById("upload-input");
uploadInput.addEventListener("change", handleFileUpload);

function handleFileUpload(event) {
  const file = event.target.files[0];
  // Implement file upload logic here
}

// Handle search form submission (you'll need to implement the search logic)
const searchForm = document.getElementById("search-form");
searchForm.addEventListener("submit", handleSubmit);

function handleSubmit(event) {
  event.preventDefault();
  const searchQuery = document.getElementById("search-input").value; // Ensure this input exists in your HTML
  // Implement search logic here
}

// Update hero video and About Us content on page load
window.addEventListener("load", () => {
  updateHeroVideo(); // Update video on load
  updateAboutContent(); // Update About Us content on load
  setInterval(updateHeroVideo, 5000); // Change video every 5 seconds
  setInterval(updateAboutContent, 5000); // Change About Us content every 5 seconds
});
