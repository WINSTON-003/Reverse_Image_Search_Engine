from flask import Flask, request, render_template, send_file
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.models import Model
import cv2
import os
import io
from PIL import Image
import base64

app = Flask(__name__)
os.chdir(r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Fashion Data\\")

image_dir = r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Fashion Data\images"

features = np.load('fashion_product_features.npy')

# Get list of all image file names in the directory
image_files = sorted([f for f in os.listdir(image_dir) if os.path.isfile(os.path.join(image_dir, f))])

# Load the ResNet50 model for feature extraction
base_model = ResNet50(weights='imagenet', include_top=False, pooling='avg')
model = Model(inputs=base_model.input, outputs=base_model.output)

# Preprocess the image (resize, normalize)
def preprocess_image(image):
    image = cv2.resize(image, (224, 224))
    image = preprocess_input(image)
    return image

# Function to find similar images
def find_similar_images(query_image, features, top_n=20):
    query_feature = model.predict(np.expand_dims(query_image, axis=0))
    similarities = cosine_similarity(query_feature, features)
    similar_indices = np.argsort(similarities[0])[::-1][:top_n]
    return similar_indices

@app.route('/', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':
        # Get the uploaded image in-memory
        file = request.files['image']
        image_stream = io.BytesIO(file.read())
        image = Image.open(image_stream)
        image = np.array(image)

        # Preprocess and find similar images
        query_image = preprocess_image(image)
        similar_indices = find_similar_images(query_image, features)

        similar_images = []
        for idx in similar_indices:
            # Load similar image directly and convert to base64
            similar_image_path = os.path.join(image_dir, image_files[idx])
            similar_image = Image.open(similar_image_path)
            buffered = io.BytesIO()
            similar_image.save(buffered, format="JPEG")
            img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
            similar_images.append(img_str)

        # Reverse normalization for display (multiply by 255)
        display_image = (query_image * 255).astype('uint8')

        # Convert original image to base64 for display (skip preprocessing)
        buffered = io.BytesIO()
        query_image_pil = Image.open(image_stream)  # Use the original image stream
        query_image_pil.save(buffered, format="JPEG")
        query_image_str = base64.b64encode(buffered.getvalue()).decode('utf-8')

        # Render the template with the query image and similar images
        return render_template('index2.html', query_image=query_image_str, similar_images=similar_images)

    return render_template('index2.html')

if __name__ == '__main__':
    app.run(debug=True)
