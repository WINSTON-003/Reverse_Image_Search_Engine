import numpy as np
from flask import Flask, request, render_template
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.models import Model
import cv2
import io
from PIL import Image
import base64
from sklearn.metrics.pairwise import cosine_similarity
import os

app = Flask(__name__)

# Directory setup
os.chdir(r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Book Data\book-covers")

# Load pre-trained features and labels
features = np.load('book_cover_resnet_features.npy')
labels = np.load('book_cover_labels.npy')

# Load the pre-trained ResNet50 model
base_model = ResNet50(weights='imagenet', include_top=False, pooling='avg')
model = Model(inputs=base_model.input, outputs=base_model.output)

def extract_features(image):
    image = cv2.resize(image, (224, 224))
    image = preprocess_input(image)
    image = np.expand_dims(image, axis=0)
    features = model.predict(image).flatten()
    return features

def predict_label(uploaded_image):
    uploaded_features = extract_features(uploaded_image).reshape(1, -1)
    similarities = cosine_similarity(uploaded_features, features)
    most_similar_index = np.argmax(similarities)
    return labels[most_similar_index]

@app.route('/', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':
        file = request.files['image']
        image_stream = io.BytesIO(file.read())
        image = Image.open(image_stream)
        image = np.array(image)

        predicted_label = predict_label(image)
        print(f"Predicted label: {predicted_label}")

        # Placeholder: Add your logic to find similar images and display them
        similar_images = []

        image_stream.seek(0)
        query_image_str = base64.b64encode(image_stream.read()).decode('utf-8')

        return render_template('index3.html', query_image=query_image_str, similar_images=similar_images,
                               predicted_label=predicted_label)

    return render_template('index3.html')

if __name__ == '__main__':
    app.run(debug=True)
