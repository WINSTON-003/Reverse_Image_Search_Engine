document.addEventListener('DOMContentLoaded', () => {
    // Retrieve query parameters from URL
    const params = new URLSearchParams(window.location.search);
    const queryImageData = params.get('query'); // Base64 image data for query image
    const relatedImagesData = JSON.parse(params.get('related_images')); // JSON string of related images' Base64 data
    const similarityPercentage = params.get('similarity'); // Similarity percentage

    // Handle the query image
    const queryImage = document.getElementById('query-image');
    if (queryImageData) {
        queryImage.src = `data:image/jpeg;base64,${queryImageData}`;
    } else {
        queryImage.src = 'path_to_default_image'; // Fallback image if no file is uploaded
    }

    // Display the similarity percentage
    const percentageElement = document.getElementById('similarity-percentage');
    if (similarityPercentage) {
        percentageElement.textContent = `${similarityPercentage}%`;
    } else {
        percentageElement.textContent = 'Not available'; // Default text if percentage is not provided
    }

    // Populate related images
    const imageGrid = document.getElementById('image-grid');
    if (Array.isArray(relatedImagesData)) {
        relatedImagesData.forEach((imageData, index) => {
            // Create a download link
            const link = document.createElement('a');
            link.href = `data:image/jpeg;base64,${imageData}`;
            link.download = `related_image_${index}.jpg`; // Optionally, give a specific name for each download

            // Create an image element
            const img = document.createElement('img');
            img.src = `data:image/jpeg;base64,${imageData}`;
            img.alt = 'Related Image';

            // Append image to link, and link to grid
            link.appendChild(img);
            imageGrid.appendChild(link);
        });
    } else {
        const noImagesText = document.createElement('p');
        noImagesText.textContent = 'No similar images found.';
        imageGrid.appendChild(noImagesText);
    }
});
