import os
import numpy as np
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import Model
from sklearn.preprocessing import LabelEncoder
from PIL import UnidentifiedImageError


dataset_dir = r"C:\Users\WINSTON A\Documents\Monisha Mam Project\Book Data\book-covers"
output_features_file = 'book_cover_resnet_features.npy'
output_labels_file = 'book_cover_labels.npy'

# List directories (each directory is a label/class)
classes = sorted(os.listdir(dataset_dir))

# Initialize arrays to hold features and labels
features = []
labels = []

# Load the pre-trained ResNet50 model + higher level layers
base_model = ResNet50(weights='imagenet', include_top=False, pooling='avg')
for label in classes:
    class_dir = os.path.join(dataset_dir, label)
    for image_file in os.listdir(class_dir):
        image_path = os.path.join(class_dir, image_file)

        try:
            image = load_img(image_path, target_size=(224, 224))
            image = img_to_array(image)
            image = np.expand_dims(image, axis=0)
            image = image / 255.0  # Normalize image
            feature_vector = base_model.predict(image)
            features.append(feature_vector.flatten())
            labels.append(label)

        except UnidentifiedImageError:
            print(f"Skipping file: {image_file} - Unidentified Image Error")

features = np.array(features)
labels = np.array(labels)
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels)

np.save(output_features_file, features)
np.save(output_labels_file, encoded_labels)

print(f"Features saved to {output_features_file}")
print(f"Labels saved to {output_labels_file}")
