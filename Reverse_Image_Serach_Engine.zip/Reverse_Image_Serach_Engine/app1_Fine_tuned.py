from flask import Flask, request, render_template
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from tensorflow.keras.applications import VGG16
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout, BatchNormalization
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.optimizers import Adam
import cv2
import os
import io
from PIL import Image
import base64

app = Flask(__name__)

# Change to your working directory
os.chdir(r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cars_train\\')

# Load the saved features and labels
features = np.load('car_features.npy')

# Directory where car images are stored
image_dir = r'C:\Users\WINSTON A\Documents\Monisha Mam Project\cars_train\cars_train'

# Get list of all image file names in the directory
image_files = sorted([f for f in os.listdir(image_dir) if os.path.isfile(os.path.join(image_dir, f))])

# Load the pre-trained VGG16 model for feature extraction
base_model = VGG16(weights='imagenet', include_top=False)

# Add custom layers for fine-tuning
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(1024, activation='relu')(x)
x = BatchNormalization()(x)
x = Dropout(0.5)(x)  # Add dropout to reduce overfitting
predictions = Dense(features.shape[1], activation='softmax')(x)  # Adjust the output layer to match your feature size

# Create the model
model = Model(inputs=base_model.input, outputs=predictions)

# Freeze the layers of the base model
for layer in base_model.layers:
    layer.trainable = False

# Compile the model with a low learning rate
model.compile(optimizer=Adam(learning_rate=0.0001), loss='categorical_crossentropy')

# Data augmentation
datagen = ImageDataGenerator(
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest'
)

# Fine-tune the model on your dataset
# Assuming you have a dataset of car images and labels
# model.fit(datagen.flow(train_data, train_labels, batch_size=32), epochs=10, validation_data=(val_data, val_labels))

# Preprocess the image (resize, normalize)
def preprocess_image(image):
    image = cv2.resize(image, (224, 224))
    image = image / 255.0
    return image

# Function to find similar images
def find_similar_images(query_image, features, top_n=20):
    query_feature = model.predict(np.expand_dims(query_image, axis=0))
    similarities = cosine_similarity(query_feature, features)
    similar_indices = np.argsort(similarities[0])[::-1][:top_n]
    return similar_indices

@app.route('/', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':
        # Get the uploaded image in-memory
        file = request.files['image']
        image_stream = io.BytesIO(file.read())
        image = Image.open(image_stream)
        image = np.array(image)

        # Preprocess and find similar images
        query_image = preprocess_image(image)
        similar_indices = find_similar_images(query_image, features)

        similar_images = []
        for idx in similar_indices:
            # Load similar image directly and convert to base64
            similar_image_path = os.path.join(image_dir, image_files[idx])
            similar_image = Image.open(similar_image_path)
            buffered = io.BytesIO()
            similar_image.save(buffered, format="JPEG")
            img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
            similar_images.append(img_str)

        # Convert query image to base64
        buffered = io.BytesIO()
        query_image_pil = Image.fromarray((query_image * 255).astype('uint8'))
        query_image_pil.save(buffered, format="JPEG")
        query_image_str = base64.b64encode(buffered.getvalue()).decode('utf-8')

        # Render the template with the query image and similar images
        return render_template('index2.html', query_image=query_image_str, similar_images=similar_images)

    return render_template('index2.html')

if __name__ == '__main__':
    app.run(debug=True)
