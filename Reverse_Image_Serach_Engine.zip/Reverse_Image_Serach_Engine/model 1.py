import cv2 as cv
import os
import numpy as np

people_list = []
for i in os.listdir(r'C:\Users\WINSTON A\Pictures\Faces Train'):
    people_list.append(i)

print(people_list)

class FaceRecognizer:
    def __init__(self, haar_cascade_path, people_list):
        self.haar_cascade = cv.CascadeClassifier(haar_cascade_path)
        self.face_recognizer = cv.face.LBPHFaceRecognizer_create()
        self.people = people_list
        self.features = []
        self.labels = []

    def create_train(self, dir_path):
        for person in self.people:
            path = os.path.join(dir_path, person)  # Joining the paths of all names in the list
            label = self.people.index(person)

            for img in os.listdir(path):
                img_path = os.path.join(path, img)
                img_array = cv.imread(img_path)
                gray = cv.cvtColor(img_array, cv.COLOR_BGR2GRAY)

                faces_rectangle = self.haar_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=3)

                for (x, y, w, h) in faces_rectangle:
                    faces_roi = gray[y:y+h, x:x+w]
                    self.features.append(faces_roi)
                    self.labels.append(label)

        self.features = np.array(self.features, dtype='object')
        self.labels = np.array(self.labels)

    def train_recognizer(self):
        self.face_recognizer.train(self.features, self.labels)
        self.face_recognizer.save("face_trained.yml")

    def load_trained_model(self, trained_model_path):
        self.face_recognizer.read(trained_model_path)

    def recognize_face(self, image_path):
        img = cv.imread(image_path)
        gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        faces_rectangle = self.haar_cascade.detectMultiScale(gray, 1.1, 3)

        for (x, y, w, h) in faces_rectangle:
            faces_roi = gray[y:y+h, x:x+w]
            label, confidence = self.face_recognizer.predict(faces_roi)
            print(f'label = {self.people[label]} and the confidence = {confidence}')



# Example usage:
haar_cascade_path = r'C:\Users\WINSTON A\Documents\Python_projects\haar_faces.txt'
dir_path = r'C:\Users\WINSTON A\Pictures\Faces Train'
face_recognizer = FaceRecognizer(haar_cascade_path, people_list)

# Create training data
face_recognizer.create_train(dir_path)

# Train the recognizer
face_recognizer.train_recognizer()

# Or load an already trained model
face_recognizer.load_trained_model("face_trained.yml")

# Recognize a face in a new image
face_recognizer.recognize_face(r'C:\Users\WINSTON A\Pictures\tobey_val.jpeg')
